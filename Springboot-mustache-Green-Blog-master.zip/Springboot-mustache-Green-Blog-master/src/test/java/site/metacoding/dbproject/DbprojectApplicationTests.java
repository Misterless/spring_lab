package site.metacoding.dbproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
